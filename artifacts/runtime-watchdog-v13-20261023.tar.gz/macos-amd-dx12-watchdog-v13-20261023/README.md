# Watchdog v13 diagnostic checkpoint

This archive contains only the open-source MoltenVK candidate, the project diagnostic proxy, and the tested configuration. It is a diagnostic checkpoint, not a playable release or a generic installer.

It contains no game, Steam client, Wine prefix, save, credential, shader cache, Apple library, or Tencent/App Store Wine binary. A compatible local Wine environment must be supplied separately. The proxy is path-bound to the original research checkout and should be rebuilt from source for another machine.

See `docs/CHECKPOINT-2026-10-23.md` in the source repository.

Source candidate: `11e1412231c0f6ad8d8e8d05414f0a50b56072da4b2a31b1bc09df918caf1781`

Game status: not playable. The next task is exact draw/dispatch attribution inside the observed 23-encoder watchdog.
